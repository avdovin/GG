-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 04 2013 г., 13:01
-- Версия сервера: 5.5.29
-- Версия PHP: 5.3.10-1ubuntu3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ifrog_tandem`
--

-- --------------------------------------------------------

--
-- Структура таблицы `keys_banners`
--

DROP TABLE IF EXISTS `keys_banners`;
CREATE TABLE IF NOT EXISTS `keys_banners` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `tbl` varchar(64) NOT NULL DEFAULT '',
  `lkey` varchar(64) NOT NULL DEFAULT '',
  `object` varchar(8) NOT NULL DEFAULT '',
  `settings` text NOT NULL,
  `edate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `tbl` (`tbl`,`lkey`,`object`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Ключи к модулю Баннерокрутилка' AUTO_INCREMENT=60 ;

--
-- Дамп данных таблицы `keys_banners`
--

INSERT INTO `keys_banners` (`ID`, `name`, `tbl`, `lkey`, `object`, `settings`, `edate`) VALUES
(1, 'Добавить запись', '', 'add_link', 'button', 'type_link=loadcontent\r\ntable_list=1\r\ncontroller=banners\r\nimageiconmenu=/admin/img/icons/menu/icon_add.png\r\naction=add\r\ntitle=Добавить\r\nrating=1\r\nparams=replaceme', '0000-00-00 00:00:00'),
(3, 'Удалить запись', '', 'del_link', 'button', 'type_link=loadcontent\r\ncontroller=banners\r\naction=delete\r\nconfirm=Действительно удалить запись?\r\nimageiconmenu=/admin/img/icons/menu/icon_delete.png\r\ntitle=Удалить запись\r\nprint_info=1\r\nrating=1\r\nparams=replaceme,index', '0000-00-00 00:00:00'),
(4, 'Редактировать запись', '', 'edit_link', 'button', 'type_link=loadcontent\r\nprint_info=1\r\ncontroller=banners\r\nimageiconmenu=/admin/img/icons/menu/icon_edit.png\r\naction=edit\r\ntitle=Редактировать запись\r\nrating=2\r\nparams=replaceme,index', '0000-00-00 00:00:00'),
(5, 'Закончить редактирование', '', 'end_link', 'button', 'type_link=loadcontent\r\nedit_info=1\r\ncontroller=banners\r\nimageiconmenu=/admin/img/icons/menu/icon_ok.png\r\naction=info\r\ntitle=Закончить редактирование\r\nrating=1\r\nparams=replaceme,index', '0000-00-00 00:00:00'),
(6, 'Фильтр', '', 'filter', 'button', 'type_link=modullink\r\ntable_list=1\r\ntable_list_view=1\r\ncontroller=banners\r\nimageiconmenu=/admin/img/icons/menu/icon_filter.png\r\naction=filter\r\ntitle=Фильтр\r\nwidth=690\r\nheight=510\r\nlevel=3\r\nrating=2\r\nparams=replaceme', '0000-00-00 00:00:00'),
(7, 'Очистка фильтра', '', 'filter_clear', 'button', 'type_link=loadcontent\r\ntable_list=1\r\ntable_list_view=1\r\ncontroller=banners\r\nimageiconmenu=/admin/img/icons/menu/icon_nofilter.png\r\naction=filter_clear\r\ntitle=Снять фильтры\r\nrating=3\r\nparams=replaceme', '0000-00-00 00:00:00'),
(10, 'Название баннера', '', 'name', 'lkey', 'type=s\nfilter=1\ntable_list=1\nrequired=1\nqview=1\nqedit=1\ngroup=1\nrating=1\nno_format=1\nhelp=Название баннера предназначено для облегчения его дальнейшей идентификации в системе. Чем четче будет название, тем легче будет найти баннер среди прочих', '2010-09-13 15:28:12'),
(11, 'Публиковать рекламу', '', 'view', 'lkey', 'type=chb\nrating=11\ngroup=1\nyes=отображать\nno=скрыть\nfilter=1\ntable_list=6\ntable_list_name=-\ntable_list_nosort=1\ntable_list_width=50\nqview=1\nhelp=Для того, чтобы баннер показывался, необходимо установить данный влажок.', '2010-09-13 15:28:12'),
(12, 'Ширина', '', 'width', 'lkey', 'type=d\r\ngroup=2\r\nqview=1\r\nfilter=1\r\nrequired=1\r\ntable_list=4\r\ntable_list_name=W\r\ntable_list_width=32\r\nrating=15\r\nhelp=Ширина баннера. По умолчанию задается из размеров выбраного баннерого места\r\n', '2010-09-13 15:28:29'),
(58, 'Цена за клик', '', 'per_click', 'lkey', 'type=d\r\nprint=1\r\nqview=1\r\nqedit=1\r\nrating=10\r\nfileview=1\r\ntable_list=4\r\ntable_list_width=100\r\n', '0000-00-00 00:00:00'),
(13, 'Высота', '', 'height', 'lkey', 'type=d\r\ngroup=2\r\nrating=16\r\nrequired=1\r\ntable_list=5\r\ntable_list_name=H\r\ntable_list_width=32\r\nqview=1\r\nfilter=1\r\nhelp=Высота баннера. По умолчанию задается из размеров выбраного баннерого места\r\n', '2010-09-13 15:28:29'),
(14, 'Код рекламного блока', '', 'code', 'lkey', 'type=code\ngroup=2\nrating=10\nhelp=Если у вас готовый код, то воспользуйтесь данным полем. Все остальные поля заполнять в этом случае не надо.', '2010-09-13 15:28:29'),
(15, 'Бюджет', '', 'cash', 'lkey', 'type=d\r\ntable_list=6\r\ntable_list_width=72\r\ngroup=1\r\nqedit=1\r\nfilter=1\r\nrating=98\r\nhelp=Доступное количество денег для открутки показов. Снимается сумма, которая прописана в настройках рекламного места и, в зависимости от типа показов, (за клики, за показы). Если выбран тип показа "без ограничения", то данное поле можно не заполнять', '2010-09-13 15:28:12'),
(16, 'Дата конца показов', '', 'showdateend', 'lkey', 'type=date\ngroup=3\nrating=8\nfilter=1\nhelp=Установите дату окончания показов, если показ баннера привязан к конкретному сроку (для коммерческих показов)', '2010-09-13 15:28:44'),
(17, 'Дата начала показов', '', 'showdatefirst', 'lkey', 'type=date\ngroup=3\nrating=7\nfilter=1\nhelp=Установите дату начала показов, если показ баннера привязан к конкретному сроку (для коммерческих показов)', '2010-09-13 15:28:44'),
(18, 'URL-ссылка', '', 'link', 'lkey', 'type=site\r\ngroup=1\r\nrating=2\r\nqview=1\r\nhelp=Адрес ссылки, куда ведет баннер.\r\ntable_list=5\r\ntable_list_width=200\r\n', '2010-09-13 15:28:12'),
(20, 'Тип показа баннера', '', 'type_show', 'lkey', 'type=list\r\nlist=0|без ограничения~1|по показам~2|по переходам\r\nlist_type=radio\r\ngroup=1\r\nrating=99\r\nfilter=1\r\nqview=1\r\nhelp=Опция для коммерческого показа баннеров. В зависимости от выбранного типа расходуется (или не расходуется) рекламный бюджет', '2010-09-13 15:28:12'),
(21, 'Рекламодатель', '', 'id_advert_users', 'lkey', 'type=tlist\r\nlist=data_banner_advert_users\r\nadd_to_list=1\r\nwin_scroll=0\r\nwin_height=100\r\nrating=100\r\ngroup=1\r\nfilter=1\r\nwidth=650\r\nheight=300\r\nhelp=Если баннерокрутилка используется для коммерческого показа баннеров, то указав рекламодателя, можно сделать ему доступ к статистике показов и переходов данного баннера.', '2010-09-13 15:28:12'),
(22, 'Текст ссылки', '', 'textlink', 'lkey', 'type=s\ngroup=2\nrating=1\nhelp=Если требуется показывать рекламную ссылку, а не графический баннер, то воспользуйтесь этим полем', '2010-09-13 15:28:29'),
(23, 'Размер файла', '', 'size', 'lkey', 'type=d\nshablon_w=field_input_read\nrating=20\ngroup=2\n', '2009-04-19 00:18:01'),
(24, 'Тип файла', '', 'type_file', 'lkey', 'type=slat\ngroup=2\nrating=21\ntable_list=2\ntable_list_name=-\ntable_list_nosort=1\ntable_list_width=16\nshablon_w=field_input_read\n', '2009-04-19 00:18:01'),
(25, 'Заголовок ссылки', '', 'titlelink', 'lkey', 'type=s\ngroup=2\nrating=2\nhelp=Текстовый баннер может состоять из заголовка и текста. Это поле предназначено для определения заголовка текстового рекламного блока', '2010-09-13 15:28:29'),
(26, 'Картинка', '', 'docfile', 'lkey', 'type=pict\r\nrating=1\r\ngroup=2\r\ntable_list=3\r\ntable_list_name=-\r\ntable_list_type=pict\r\ntable_list_nosort=1\r\ntemplate_w=field_file\r\ntemplate_r=field_pict_read\r\nfolder=/image/bb/\r\nsizelimit=20000\r\nfile_ext=*.jpg;*.jpeg;*.gif;*.swf;*.png\r\nhelp=Баннер может быть загружен на сервер.', '2010-09-13 15:24:47'),
(27, 'Постраничный таргетинг', '', 'target', 'lkey', 'type=list\r\nlist=0|на всех страницах~1|только на страницах~2|исключая страницы\r\nlist_type=radio\r\nlist_sort=asc_d\r\ngroup=3\r\nrating=10\r\nhelp=Баннер может показываться на определенных страницах. Для этого выберите режим <b>Только на страницах</b> и в поле <b>Список страниц</b> укажите эти страницы. В режиме <b>Исключая страницы</b> баннер будет показан на всех страницах, за исключением тех, которые указаны в списке.', '2010-09-13 15:28:44'),
(29, 'Дни недели', '', 'week', 'lkey', 'type=list\r\nlist=-1|Все дни~1|Понедельник~2|Вторник~3|Среда~4|Четверг~5|Пятница~6|Суббота~7|Воскресенье\r\nlist_type=checkbox\r\nlist_sort=asc_d\r\nnotnull=1\r\ngroup=3\r\nrating=4\r\nhelp=Для коммерческого показа рекламы можно использовать таргетинг по дням. Если таргетинг по дням не используется, то установите флажок в положение "Все дни", в противном случае баннер показываться не будет', '2010-09-13 15:28:44'),
(32, 'Время показов', '', 'time', 'lkey', 'type=list\r\nlist=-1|Все время&nbsp;&nbsp;&nbsp;~1|00:00-01:00~2|01:00-02:00~3|02:00-03:00~4|03:00-04:00~5|04:00-05:00~6|05:00-06:00~7|06:00-07:00~8|07:00-08:00~9|08:00-09:00~10|09:00-10:00~11|10:00-11:00~12|11:00-12:00~13|12:00-13:00~14|13:00-14:00~15|14:00-15:00~16|15:00-16:00~17|16:00-17:00~18|17:00-18:00~19|18:00-19:00~20|19:00-20:00~21|20:00-21:00~22|21:00-22:00~23|22:00-23:00~24|23:00-24:00\r\nlist_type=checkbox\r\nlist_sort=asc_d\r\nnotnull=1\r\ngroup=3\r\nrating=5\r\nhelp=Для коммерческого показа рекламы можно использовать таргетинг по времени. Если таргетинг по времени не используется, то установите флажок в положение "Все время", в противном случае баннер показываться не будет', '2010-09-13 15:28:44'),
(33, 'Место', '', 'id_advert_block', 'lkey', 'type=tlist\r\nlist=data_banner_advert_block\r\ngroup=1\r\nrating=6\r\nfilter=1\r\nrequired=1\r\ntable_list=5\r\nqview=1\r\nshablon_w=field_multselect\r\nnotnull=1\r\nhelp=Баннер можно привязать к нескольким местам, которые прописаны в системе и в шаблонах. Желательно соблюдать размерность баннера и места, на которое он размещается, чтобы не портить верстку макета страницы\r\n', '2010-09-13 15:28:44'),
(36, 'Статистика', '', 'stat', 'lkey', 'type=table\r\ntable=dtbl_banner_stat\r\ngroup=4\r\nrating=15\r\ntemplate_w=field_table\r\ntable_fields=tdate,view_count,view_pay,click_count,click_pay\r\ntable_svf=id_banner\r\ntable_sortfield=tdate\r\ntable_buttons_key_w=delete\r\ntable_groupname=Общая информация\r\ntable_noindex=1\r\nhelp=Статистика показов и переходов за период. При клике по названию поля в таблице происходит сортировка по данному полю. Повторный клик приводит к обратной сортировке ', '2009-04-19 00:18:01'),
(37, 'Списано за клики', '', 'click_pay', 'lkey', 'type=d\nfloor=1\nrating=31\ngroup=1', '2008-08-13 15:48:49'),
(38, 'Кол-во переходов', '', 'click_count', 'lkey', 'type=d\ngroup=1\nrating=2', '2008-08-13 15:48:49'),
(39, 'Списано за показы', '', 'view_pay', 'lkey', 'type=d\nfloor=1\nrating=30\ngroup=1', '2008-08-13 15:48:49'),
(40, 'Кол-во просмотров', '', 'view_count', 'lkey', 'type=d\ngroup=1\nrating=1', '2008-08-13 15:48:49'),
(41, 'Дата', '', 'tdate', 'lkey', 'type=date\nrating=7\ngroup=1\nshablon_w=field_input_read', '0000-00-00 00:00:00'),
(42, 'Файл', '', 'filename', 'lkey', 'type=filename\nrating=2\nsizelimit=20000\nfile_ext=*.*', '2010-09-13 15:24:08'),
(43, 'Флаг удаления картинки', '', 'deletepict', 'lkey', 'type=chb\nsys=1', '2008-10-26 13:53:51'),
(44, 'Список страниц', '', 'list_page', 'lkey', 'type=tlist\r\nlist=texts_main_ru\r\nsort=1\r\nrating=22\r\ngroup=3\r\nmult=5\r\nrequest_url=/admin/banners/body\r\nnotdef=1\r\ntemplate_w=field_multselect_input\r\nhelp=Данное поле работает в паре с полем <b>Постраничный таргетинг</b>. Для выбора страниц нажмите на ссылку <b>Расширенный поиск</b>, расположенную слева. Появятся несколько дополнительных полей. В поле <b>поиск</b> введите подстроку, содержащуюся в названии страницы. В поле <b>доступные значения</b> появятся документы, которые содержат данную подстроку. При помощи кнопок со стрелками, расположенными справа, перенесите нужные страницы во второе поле <b>Выбранные значения</b>. Из последнего поля можно удалить документы, воспользовавшись соответствующими кнопками справа.\r\n', '2010-09-13 15:28:44'),
(45, 'Флаг показать', '', 'show', 'lkey', 'type=s\nsys=1', '2009-04-29 17:55:04'),
(46, 'Флаг скрыть', '', 'hide', 'lkey', 'type=s\nsys=1', '0000-00-00 00:00:00'),
(47, 'ключ', '', 'texts_main_ru', 'lkey', 'type=tlist\nlist=texts_main_ru', '0000-00-00 00:00:00'),
(48, 'Баннер', '', 'id_banner', 'lkey', 'type=tlist\nlist=data_banner\nsort=1\nsys=1', '2009-04-17 12:43:22'),
(50, 'Список', '', 'list_link', 'button', 'type_link=loadcontent\r\nadd_info=1\r\ncontroller=banners\r\nimageiconmenu=/admin/img/icons/menu/button.list.png\r\naction=enter\r\ntitle=Список\r\nrating=1\r\nparams=replaceme', '0000-00-00 00:00:00'),
(51, 'Рейтинг', '', 'rating', 'lkey', 'type=d\r\ngroup=1\r\nfilter=1\r\nrating=15\r\ntable_list=9\r\ntable_list_name=Rt\r\ntable_list_width=32\r\nqedit=1\r\nqview=1\r\nshablon_w=field_rating\r\nhelp=При прочих равных условиях, чем меньше рейтинг, тем чаще будет показываться баннер. Используется, если на одно место прописано несколько баннеров', '2010-09-13 15:28:12'),
(52, 'Индекс', '', 'index', 'lkey', 'type=d\r\nsys=1', '2010-10-27 16:37:28'),
(53, 'IP адреса', '', 'ip_data_click', 'lkey', 'type=code\r\nprint=1\r\nqview=1\r\nrating=99\r\ngroup=1\r\n', '0000-00-00 00:00:00'),
(54, 'Имя рекламодателя', 'lst_advert_users', 'name', 'lkey', 'type=s\r\nfilter=1\r\ntable_list=1\r\nrequired=1\r\nqview=1\r\nqedit=1\r\ngroup=1\r\nrating=1\r\nno_format=1\r\n', '0000-00-00 00:00:00'),
(55, 'E-mail', '', 'email', 'lkey', 'type=email\r\nprint=1\r\nqview=1\r\nqedit=1\r\nrating=5\r\ntable_list=4\r\ntable_list_width=100\r\n', '0000-00-00 00:00:00'),
(56, 'Телефон', '', 'phone', 'lkey', 'type=s\r\nprint=1\r\nqview=1\r\nqedit=1\r\nrating=5\r\ntable_list=3\r\ntable_list_width=100\r\n', '0000-00-00 00:00:00'),
(57, 'Открывать в новом окне', '', 'targetblank', 'lkey', 'type=chb\r\nprint=1\r\nqview=1\r\nqedit=1\r\nrating=1\r\nfilter=1\r\nqview=1\r\nrating=3\r\ngroup=1\r\nyes=Да\r\nno=Нет\r\nhelp=Если указана URL-ссылка, то она будет открываться в новом окне', '0000-00-00 00:00:00'),
(59, 'Цена за показ', '', 'per_show', 'lkey', 'type=d\r\nprint=1\r\nqview=1\r\nqedit=1\r\nrating=11\r\nfileview=1\r\ntable_list=5\r\ntable_list_width=100\r\n', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
