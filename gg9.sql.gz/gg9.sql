-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 13 2013 г., 18:59
-- Версия сервера: 5.5.29
-- Версия PHP: 5.3.10-1ubuntu3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ifrog_tandem`
--

-- --------------------------------------------------------

--
-- Структура таблицы `data_users`
--

DROP TABLE IF EXISTS `data_users`;
CREATE TABLE IF NOT EXISTS `data_users` (
  `ID` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `cck` varchar(128) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mname` varchar(150) NOT NULL,
  `fname` varchar(150) NOT NULL,
  `post` varchar(150) NOT NULL,
  `company` varchar(255) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `id_manager` int(6) unsigned NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `edate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `operator` varchar(100) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 PACK_KEYS=0 COMMENT='Таблица с паролями' AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `data_users`
--

INSERT INTO `data_users` (`ID`, `cck`, `name`, `mname`, `fname`, `post`, `company`, `phone`, `id_manager`, `email`, `password`, `edate`, `vdate`, `rdate`, `operator`, `active`, `data`) VALUES
(1, 'cab9f6fceed5d850404747dfdfca5fa5', 'adfsaf', '', '', '', '', '', 0, 'test@test.ru', '123', '2013-03-13 17:19:27', '0000-00-00 00:00:00', '2013-03-07 19:06:08', '', 1, ''),
(2, '', 'adfsaf', '', '', '', '', '', 0, 'test2@test.ru', '123', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2013-03-07 19:06:28', '', 1, ''),
(3, '', 'Алексей', '', '', '', '', '', 4, 'test3@test.ru', 'test', '2013-03-13 18:21:07', '0000-00-00 00:00:00', '2013-03-07 19:08:12', 'root', 1, ''),
(6, '', 'Александр', '', '', '', '', '', 4, '7902633@mail.ru', 'unreal', '2013-03-13 18:43:43', '0000-00-00 00:00:00', '2013-03-13 18:32:00', 'root', 1, ''),
(5, '', 'Кирилл', '', '', '', '', '', 4, 'ktoesline@ya.ru', '123', '2013-03-13 18:24:47', '0000-00-00 00:00:00', '2013-03-13 18:12:17', 'root', 1, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
