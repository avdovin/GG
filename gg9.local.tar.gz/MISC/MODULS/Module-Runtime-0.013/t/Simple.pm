package t::Simple;

{ use 5.006; }
use warnings;
use strict;

our $VERSION = 1;

"t::Simple return";
