#!/usr/bin/env perl
package Class::Load::SyntaxError;
use strict;
use warnings;

sub {

