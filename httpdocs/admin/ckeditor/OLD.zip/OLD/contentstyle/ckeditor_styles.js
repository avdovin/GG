CKEDITOR.stylesSet.add(
	'content_styles',
	[
		{name:'Blue Title',element:'h3',styles:{color:'Blue'}},
		{name:'Red Title',element:'h3',styles:{color:'Red'}}
	]
);
